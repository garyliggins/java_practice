package src.main.model.account;

public class Loan {


}
