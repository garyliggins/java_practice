public class Main {

    static final double TARGET = 0.5;
    static final double PRECISION = 0.000000001;

    public static void main(String[] args) {

        //call generateNumber here...
        //calculate precision level here...
        System.out.println("The computer returned a value of: " + <result>);
        System.out.println("The value was generated to a precision of : " + <precision>);
    }

    /**
     * Function name: generateNumber
     * @return double
     * 
     * Inside the function:
     *   1. Generates a number close to the TARGET to a precision of PRECISION.
     * 
     */


}
