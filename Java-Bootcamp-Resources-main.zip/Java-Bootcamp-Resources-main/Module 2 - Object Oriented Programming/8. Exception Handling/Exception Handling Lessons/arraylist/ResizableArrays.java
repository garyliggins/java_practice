public class ResizableArrays {
    public static void main(String[] args) {
        
    }
}
