public class RuntimeException2 {
    public static void main(String[] args) {
        String word = null;
        
    }
}
