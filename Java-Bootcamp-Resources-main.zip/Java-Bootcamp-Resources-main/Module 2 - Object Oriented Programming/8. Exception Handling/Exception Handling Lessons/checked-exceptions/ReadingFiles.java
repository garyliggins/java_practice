public class ReadingFiles {
    public static void main(String[] args) {
                
    }
}
