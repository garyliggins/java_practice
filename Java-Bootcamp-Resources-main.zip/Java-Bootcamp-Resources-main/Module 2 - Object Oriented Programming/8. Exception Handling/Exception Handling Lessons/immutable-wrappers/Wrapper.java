public class Wrapper {
    public static void main(String[] args) {
        int wholeNumber = 5;
        long largeWholeNumber = 5000000000L;
        double decimal = 5.493;
        char letter = 'b';
    }
}
