public class Breakpoints {
    public static void main(String[] args) {
        int number = 5;
        long bigNumber = 50000000000L;
        double decimal = 5.5;
        boolean flag = true;
        char letter = 'f';
        String word = "hello";
    }
}
