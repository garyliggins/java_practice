package src.test;

import src.main.model.account.Account;

public class SellTests {
    
    Account[] accounts;

}
