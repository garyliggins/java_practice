public class Megaphone {
    public static void main(String[] args) {
        
        //Task 1: make a for loop that prints this 10 times:
        //        If Java was easy, they would call it Python!

        //Task 2: Number each line, starting from 1 – 10. 
        //        1. If Java was easy, they would call it Python!
        //        2. If Java was easy, they would call it Python!
        //        3. If Java was easy, they would call it Python!
        //        4. If Java was easy, they would call it Python!
        //        5. If Java was easy, they would call it Python!
        //        6. If Java was easy, they would call it Python!
        //        7. If Java was easy, they would call it Python!
        //        8. If Java was easy, they would call it Python!
        //        9. If Java was easy, they would call it Python!
        //        10. If Java was easy, they would call it Python!
    }
    
}
