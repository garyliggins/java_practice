// TASK 1: Make a class.



// TASK 2: Inside the class, write the main() method.


// TASK 3: Print these messages to the console: "Printing is fun!" 
                                              // "Java > Python."
                                              // "I spilled Java all over my paper."
                                              // "My dog ate my Java." 
