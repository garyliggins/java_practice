public class YourInitials {
    public static void main(String[] args) {
        //print initials here. 
    }
}