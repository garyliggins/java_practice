//Before you look at the solution, try to write the code yourself!

public class FirstProgramSolution {
    public static void main(String[] args) {
        System.out.println( "Printing is fun!" );
		System.out.println( "Java > Python." );
		System.out.println( "I spilled Java all over my paper." );
		System.out.println( "My dog ate my Java." );
    }
}
