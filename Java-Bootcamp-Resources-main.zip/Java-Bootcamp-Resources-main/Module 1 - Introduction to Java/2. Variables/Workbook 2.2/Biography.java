public class Biography {
    public static void main(String[] args) {

        //make a name variable
        //make an age variable
        //make a country variable
        //make a sport variable
        //make an hours variable
        //make a game variable
        //make a subject variable
        //make a grade variable
     
        System.out.println("My name is <name>. I'm <age> years old, and I'm from <country> ");
        System.out.println("My favourite sport is <sport>. I play for <hours> hours a day");
        System.out.println("When I'm tired, I like to play <game>.");
        System.out.println("In school, my favourite subject was <subject>, I scored a <grade>.");

    }
}