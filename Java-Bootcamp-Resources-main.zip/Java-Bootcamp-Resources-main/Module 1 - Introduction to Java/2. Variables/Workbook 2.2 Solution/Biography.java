public class Biography {
    public static void main(String[] args) {

        String name = "Sam";
        int age = 35;
        String country = "England";
        String sport = "Basketball";
        int hours = 1;
        String game = "Checkers";
        String subject = "Chemistry";
        char grade = 'B';

        System.out.println("My name is " + name + ". I'm " + age + " years old, and I'm from "+country+". ");
        System.out.println("My favourite sport is "+sport+". I play for "+hours+" hours a day");
        System.out.println("When I'm tired, I like to play "+ game+".");
        System.out.println("In school, my favourite subject was "+subject+", I scored a "+grade+".");

    }
}